export class FindBookDto {
    title?:string;
    author?: string
}
                                